git checkout master
git merge --ff-only dev
git push origin master
git checkout dev
